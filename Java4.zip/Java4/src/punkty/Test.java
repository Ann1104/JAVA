package punkty;
public class Test {

    //psvm i tab
    public static void main(String[] args) {

        Punkt2D p1 = new Punkt2D(1, 2);
        Punkt2D p2 = new Punkt2D(3, 4);

        System.out.println(p1);
        System.out.println(p2);

        System.out.println("Liczba wspolrzednych punktu p1: "+p1.liczbaWspolrzednych());
        System.out.println("Liczba wspolrzednych punktu p2: "+p2.liczbaWspolrzednych());
        
        
        p1.setX(10);
        System.out.println(p1);
        
        //jesli int x, int y
        //p1.x=7;
        //System.out.println(p1.x);
        
        p1.setX(-10);
        System.out.println(p1);
        
        
        System.out.println(" ");
        System.out.println(" 3D ");
        
        Punkt3D t1 = new Punkt3D(1,2,3);
        System.out.println(t1);
        System.out.println("Liczba wspolrzednych punktu t1: "+t1.liczbaWspolrzednych());
       
        Random generator = new Random();
        
        double liczba = generator.nextDouble();
        
        Punkt2D p;
        if(liczba <0.5)
            p=new Punkt2D(1,2);
        else
            p=new Punkt3D(1,2,3);
        
        System.out.println(p);
        System.out.println(p.liczbaWspolrzednych());
        //gc - Garbage Collector, zamiast dekonstruktora
        System.gc();
    }

}
