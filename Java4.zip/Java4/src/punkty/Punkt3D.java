
package punkty;

//po punkt 3D e+ctrl spacja 
public class Punkt3D extends Punkt2D{
    
    private int z;

    public Punkt3D(int z, int x, int y) {
        super(x, y);
        this.z = z;
    }

    public int getZ() {
        return z;
    }

    public void setZ(int z) {
        this.z = z;
    }

    @Override
    public String toString() {
        //return super.toString(); //To change body of generated methods, choose Tools | Templates.
    //return "("+getX()+","+getY()+","+getZ()+")";
    return "("+getX()+","+getY()+","+z+")";
    }

    @Override
    public int liczbaWspolrzednych() {
        return super.liczbaWspolrzednych()+1; //To change body of generated methods, choose Tools | Templates.
    }
    
    

    
    
    
}
