package java4;

public class Test {

    public static void main(String[] args) {

        Samochod sam1 = new Samochod();

        System.out.println(sam1.getDlugosc());
        System.out.println(sam1.getSzerokosc());
        System.out.println(sam1.getPredkoscJazdy());
        System.out.println(sam1.getMarka());

        sam1.setDlugosc(4400);
        sam1.setSzerokosc(2600);
        sam1.setPredkoscJazdy(230);
        sam1.setMarka("Audi");

        System.out.println(sam1.getDlugosc());
        System.out.println(sam1.getSzerokosc());
        System.out.println(sam1.getPredkoscJazdy());
        System.out.println(sam1.getMarka());
        System.out.println("  ");
        
        Samochod sam2 = new Samochod();

        System.out.println(sam2.getDlugosc());
        System.out.println(sam2.getSzerokosc());
        System.out.println(sam2.getPredkoscJazdy());
        System.out.println(sam2.getMarka());

        sam2.setDlugosc(4200);
        sam2.setSzerokosc(2200);
        sam2.setPredkoscJazdy(180);
        sam2.setMarka("Opel");

        System.out.println(sam2.getDlugosc());
        System.out.println(sam2.getSzerokosc());
        System.out.println(sam2.getPredkoscJazdy());
        System.out.println(sam2.getMarka());

        //wyswietlenie poczatkowego miejsca w pamieci
        System.out.println("sam1: " + sam1);
        System.out.println("sam2: " + sam2);

        System.out.println("  ");
        
        Samochod sam3 = new Samochod(3800, 1900, 130, "Renault");
        System.out.println(sam3.getDlugosc());
        System.out.println(sam3.getSzerokosc());
        System.out.println(sam3.getPredkoscJazdy());
        System.out.println(sam3.getMarka());
        System.out.println("sam3: " + sam3);
        System.out.println("  ");

    }

}
