
package java4;

public class Samochod {
    
    int dlugosc;
    int szerokosc;
    int predkoscJazdy;
    String marka;

    public Samochod(int dlugosc, int szerokosc, int predkoscJazdy, String marka) {
        this.dlugosc = dlugosc;
        this.szerokosc = szerokosc;
        this.predkoscJazdy = predkoscJazdy;
        this.marka = marka;
    }

    public Samochod() {
    }
    public int getDlugosc() {
        
        
        return dlugosc;
    }

    public void setDlugosc(int dlugosc) {
        this.dlugosc = dlugosc;
    }

    public int getSzerokosc() {
        return szerokosc;
    }

    public void setSzerokosc(int szerokosc) {
        this.szerokosc = szerokosc;
    }

    public int getPredkoscJazdy() {
        return predkoscJazdy;
    }

    public void setPredkoscJazdy(int predkoscJazdy) {
        this.predkoscJazdy = predkoscJazdy;
    }

    public String getMarka() {
        return marka;
    }

//ctrl spacja lub lewy alt i insert
    public void setMarka(String marka) {
        this.marka = marka;
    }

    //ctrl spacja toString
    @Override
    public String toString() {
        //super - odwolanmie do nadklasy samochod czyli object i wywołanie metody toString
        //return super.toString(); 
        
        
        return getDlugosc() + " " + getSzerokosc()+" "+ getPredkoscJazdy()+ " " + getMarka();
    }
}
