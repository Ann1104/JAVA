
package punkty;

public class Trojkat {

}
