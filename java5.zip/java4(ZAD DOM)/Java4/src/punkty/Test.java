package punkty;

import java.util.Random;
import java.util.Scanner;

public class Test {

    //psvm i tab
    public static void main(String[] args) {
        /*
         Punkt2D p1 = new Punkt2D(1, 2);
         Punkt2D p2 = new Punkt2D(3, 4);

         System.out.println(p1);
         System.out.println(p2);

         System.out.println("Liczba wspolrzednych punktu p1: "+p1.liczbaWspolrzednych());
         System.out.println("Liczba wspolrzednych punktu p2: "+p2.liczbaWspolrzednych());
        
        
         p1.setX(10);
         System.out.println(p1);
        
         //jesli int x, int y
         //p1.x=7;
         //System.out.println(p1.x);
        
         p1.setX(-10);
         System.out.println(p1);
        
        
         System.out.println(" ");
         System.out.println(" 3D ");
        
         Punkt3D t1 = new Punkt3D(1,2,3);
         System.out.println(t1);
         System.out.println("Liczba wspolrzednych punktu t1: "+t1.liczbaWspolrzednych());
       
         Random generator = new Random();
        
         double liczba = generator.nextDouble();
        
         Punkt2D p;
         if(liczba <0.5)
         p=new Punkt2D(1,2);
         else
         p=new Punkt3D(1,2,3);
        
         System.out.println(p);
         System.out.println("Liczba wspolrzednych punktu t1: "+ p.liczbaWspolrzednych());
         */

        System.out.println(" ");
        System.out.println(" Zadanie domowe:");

        Random generator = new Random();

        double liczba = generator.nextDouble();
        int a = generator.nextInt(35);
        int b = generator.nextInt(35);
        int c = generator.nextInt(35);

        Punkt2D p;
        if (liczba < 0.5) {
            p = new Punkt2D(a, b);
        } else {
            p = new Punkt3D(a, b, c);
        }

        System.out.println(p);
        System.out.println("Liczba wspolrzednych punktu t1: " + p.liczbaWspolrzednych());
        System.out.println("Odleglosc puntu od 0: " + p.odlegloscOdZera());

        System.out.println(" ");
        System.out.println(" Czesc druga zadania domowego:");

        Punkt2D[] tabPunktow = new Punkt2D[10];

        for (int i = 0; i < 10; i++) {
            double lb = generator.nextDouble();
            double pom = lb;
            System.out.println("Wartosc lb: " + lb);
            lb = lb * 1000;

            int cc = (int) lb % 10;
            int bb = (int) (lb / 10) % 10;
            int aa = (int) (lb / 100) % 10;

            if (pom < 0.5) {
                tabPunktow[i] = new Punkt2D(aa, bb);
            } else {
                tabPunktow[i] = new Punkt3D(aa, bb, cc);
            }

            System.out.println(tabPunktow[i]);
            System.out.println("Liczba wspolrzednych punktu : " + tabPunktow[i].liczbaWspolrzednych());
            System.out.println(" --- ");
        }

        System.out.println("  ");
        System.out.println("  ");

        System.out.println(" Odleglosc 2 pkt od siebie ");
        Punkt2D p1 = new Punkt2D(2, 1);
        Punkt2D p2 = new Punkt2D(1, 2);
        System.out.println("odleglosc p1: " + p1 + " od p2: " + p2 + " = " + p1.odl(p2));

        System.out.println("  ");
        System.out.println("  ");

        Punkt2D[] tabPkt = new Punkt2D[3];
        for (int i = 0; i < 3; i++) {
            int aaa = generator.nextInt(16);
            int bbb = generator.nextInt(16);

            tabPkt[i] = new Punkt2D(aaa, bbb);
        }

        boolean trojkat = Punkt2D.czyTrojkat(tabPkt[0], tabPkt[1], tabPkt[2]);
                
        if (trojkat) {
            System.out.println("Trojkat o wierzchołkach: " + tabPkt[0] + " " + tabPkt[1] + " " + tabPkt[2] + " " + " istnieje.");
            double pole = Punkt2D.poleTrojkata(tabPkt[0], tabPkt[1], tabPkt[2]);
            System.out.println("Pole trojkata = "+pole);
        } else {
            System.out.println("Trojkat o wierzchołkach: " + tabPkt[0] + " " + tabPkt[1] + " " + tabPkt[2] + " " + " nie istnieje.");
        }

        System.out.println("  ");

       Punkt2D trojkaty[] = new Punkt2D[3];
        for (int i = 0; i <3; i++) {
           int X;
       int Y;
      Scanner odczyt = new Scanner(System.in); 
            System.out.println("Podaj wspolczedne punktu numer" + i);
 X = odczyt.nextInt();
  Y =   odczyt.nextInt();
  trojkaty[i]=new Punkt2D(X,Y);
        }
       
 boolean trojkat11 = Punkt2D.czyTrojkat(trojkaty[0], trojkaty[1], trojkaty[2]);
                
        if (trojkat11
                ) {
            System.out.println("Trojkat o wierzchołkach: " + trojkaty[0] + " " +trojkaty[1] + " " + trojkaty[2] + " " + " istnieje.");
            double pole = Punkt2D.poleTrojkata(trojkaty[0],trojkaty[1], trojkaty[2]);
            System.out.println("Pole trojkata = "+pole);
        } else {
            System.out.println("Trojkat o wierzchołkach: " +trojkaty[0] + " " + trojkaty[1] + " " + trojkaty[2] + " " + " nie istnieje.");
        }
 
      
        //gc - Garbage Collector, zamiast dekonstruktora
        System.gc();
    }

}
