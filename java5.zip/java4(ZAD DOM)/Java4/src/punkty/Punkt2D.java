package punkty;

public class Punkt2D {


    //x,y widoczne w obrębie pakietu
    //int x;
    //int y;
    private int x;
    private int y;

    public Punkt2D(int x, int y) {
        if (x > 0) {
            this.x = x;
        } else {
            this.x = 0;
        }

        if (y > 0) {
            this.y = y;
        } else {
            this.y = 0;
        }
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        if (x > 0) {
            this.x = x;
        }
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        if (y > 0) {
            this.y = y;
        }
    }

    @Override
    public String toString() {
        //return super.toString(); //To change body of generated methods, choose Tools | Templates.
        return "("+getX()+","+getY()+")";
        //return "("+this.getX()+","+this.getY()+")";

        //return "(" + x + "," + y + ")";
    }

    public int liczbaWspolrzednych() {
        return 2;
    }
    
    
    public double odlegloscOdZera(){
        int kwdr = (this.x*this.x)+(this.y*this.y);
        double przekatna = Math.sqrt(kwdr);
         
        return round(przekatna);
    }
    
    
 public static double round(double number){
 number = number * 100;
 number = Math.round(number);
 number = number / 100;
 return number;
 }
 
public double odl(Punkt2D a){
int xx = a.getX()-getX();
int yy = a.getY()-getY();
int kwdr = (xx*xx)+(yy*yy);
        double przekatna = Math.sqrt(kwdr);
         
        return round(przekatna);
}


public static boolean czyTrojkat(Punkt2D A, Punkt2D B, Punkt2D C){
    double AB = A.odl(B);
    double BC = B.odl(C);
    double CA = C.odl(A);
    
    if ((AB+BC>CA) && (AB+CA>BC) && (BC+CA)>AB)
        return true;
    else 
        return false;
    
}

   public static double poleTrojkata(Punkt2D A, Punkt2D B, Punkt2D C) {
       double AB = A.odl(B);
    double BC = B.odl(C);
    double CA = C.odl(A);
    double p = (AB+BC+CA)/2;
    double poleT = Math.sqrt(p*(p-AB)*(p-BC)*(p-CA));
    
    return round(poleT);
    }

    
}
