package java6;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class Kolekcja {

    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(new File("wynik1.txt"));
            PrintWriter pw = new PrintWriter(new File("wynik2.txt"));
            HashSet<String> zbior2 = new HashSet<String>();

            while (sc.hasNext()) {
                zbior2.add(sc.next());
            }
            //przeiterowac zbior na ekran
            //zapisac elementy do pliku
            Iterator it2 = zbior2.iterator();

            while (it2.hasNext()) {
                System.out.println(it2.next());
                //pw.println(it.next());
                
            }
            
            System.out.println(zbior2.size());
            Object[] tabObj2 = zbior2.toArray();
            
            for (int i = 0; i < tabObj2.length; i++) {
                Object object2 = tabObj2[i];
                System.out.println(object2);
            }
            
            for (Object o2 : tabObj2){
                System.out.println(o2);
                pw.println(o2);
            }

        } catch (FileNotFoundException ex) {
            System.out.println("Problem z plikiem");
        }

        /*
        zbior.add("Ala");
        zbior.add("ma");
        zbior.add("kota.");
        //zbior.add("kota.");//jesli dodamy drugi taki sam element to jest on pomijany, usuwane są duplikaty jak w zwyklym zbiorze

        Iterator it = zbior.iterator();

        while (it.hasNext()) {

            System.out.println(it.next());

        }
        
        System.out.println(zbior.size());
        Object[] tabObj = zbior.toArray();
        
        //petla for
        for (int i = 0; i < tabObj.length; i++) {
            Object object = tabObj[i];
            System.out.println(object); 
        }
        
        //petla foreach
        for (Object o : tabObj)
        {
            System.out.println(o);
        }
         */
    }

}
