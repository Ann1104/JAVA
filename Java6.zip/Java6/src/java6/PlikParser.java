package java6;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class PlikParser {

    public static void main(String[] args) {

        try {
            Scanner sc = new Scanner(new File("dane.txt"));
            PrintWriter pw = new PrintWriter(new File("wynik1.txt"));
            int licznik = 0;

            while (sc.hasNext()) {
                String wyraz = sc.next();

                // String[] tabWyrazow = wyraz.split("[),.!?(]");
                // System.out.println(++licznik +" "+tabWyrazow[0]);
                //pw.println(tabWyrazow[0]);
                wyraz = wyraz.replaceAll("[),.!?(]", "");
                System.out.println(++licznik + " " + wyraz);
                if (licznik != 94) {
                    pw.println(wyraz);
                } else {
                    pw.print(wyraz);
                }
            }

            pw.flush();
        } catch (FileNotFoundException ex) {
            System.out.println("Problem z plikiem.");
        }

    }

}
